# 📱 Telegram Mini App — Мой Бюджет

## Что это такое

Мини-приложение (Web App) открывается прямо внутри Telegram —
как встроенный сайт. Защищено PIN-кодом (4 цифры).

## Возможности

| Экран         | Что умеет                                                     |
|---------------|---------------------------------------------------------------|
| 🔒 Блокировка | PIN-экран при каждом открытии; смена PIN в настройках         |
| ◎ Обзор      | Баланс месяца, расходы по категориям с прогресс-барами        |
| ≡ История     | Все транзакции текущего месяца                                |
| ↗ Год         | График план/факт по месяцам + накопительный итог              |
| ◈ Категории  | Добавить / удалить / переименовать категории расходов и доходов|
| ⊙ Настройки  | PIN, категории, экспорт JSON, сброс данных                    |
| ＋ Добавить   | Записать расход или доход с выбором категории                  |

---

## Деплой (5 минут)

### Вариант A — GitHub Pages (бесплатно, навсегда)

1. Создай репозиторий на https://github.com — например `budget-app`
2. Загрузи `index.html` в репозиторий
3. Settings → Pages → Source: main branch / root → Save
4. Через ~1 мин будет доступен: `https://твоё-имя.github.io/budget-app/`

### Вариант B — Netlify (drag-and-drop)

1. Зайди на https://netlify.com → "Add new site" → "Deploy manually"
2. Перетащи папку с `index.html`
3. Получишь URL вида `https://random-name.netlify.app`

### Вариант C — Vercel

```bash
npm i -g vercel
cd budget_miniapp
vercel --prod
```

---

## Подключить к боту

После деплоя добавь в bot.py:

```python
from telegram import InlineKeyboardButton, InlineKeyboardMarkup, WebAppInfo

APP_URL = "https://твой-домен.com"   # ← вставь свой URL

async def open_app(update, ctx):
    kb = InlineKeyboardMarkup([[
        InlineKeyboardButton("📱 Открыть бюджет", web_app=WebAppInfo(url=APP_URL))
    ]])
    await update.message.reply_text("Открыть приложение:", reply_markup=kb)

# В main() добавь:
app.add_handler(CommandHandler("app", open_app))
```

И в MAIN_KB добавь кнопку:
```python
from telegram import WebAppInfo
KeyboardButton("📱 Приложение", web_app=WebAppInfo(url=APP_URL))
```

---

## Первый вход

PIN по умолчанию: **1234**

Сразу после входа зайди в Настройки → «Изменить PIN» и поставь свой.

---

## Важно для Telegram

- URL **обязательно должен быть HTTPS** (GitHub Pages и Netlify дают автоматически)
- HTTP-ссылки Telegram не открывает в WebApp
- Данные хранятся в localStorage браузера внутри Telegram — они не синхронизируются между устройствами. Для синхронизации нужно добавить API-бэкенд (можно тот же bot.py).

---

## Синхронизация с ботом (опционально)

Если хочешь чтобы транзакции из бота и Mini App объединялись —
скажи мне, и я добавлю:
- API-эндпоинты в bot.py (FastAPI)
- `fetch()` вызовы в Mini App для сохранения на сервер
- Авторизацию через `initData` от Telegram (защита от подбора)
