"""
Добавь в bot.py команду /app — она открывает Mini App прямо в Telegram.
Вставь этот код в конец init_db() или как отдельный хэндлер.
"""

# В bot.py добавь в MAIN_KB кнопку Web App:
# from telegram import WebAppInfo
# KeyboardButton("🌐 Открыть приложение", web_app=WebAppInfo(url="https://твой-домен.com"))

# Команда /app
async def open_app(update, ctx):
    from telegram import InlineKeyboardButton, InlineKeyboardMarkup, WebAppInfo
    APP_URL = "https://твой-домен.com"   # <-- замени на свой URL
    kb = InlineKeyboardMarkup([[
        InlineKeyboardButton("🌐 Открыть бюджет", web_app=WebAppInfo(url=APP_URL))
    ]])
    await update.message.reply_text("Открыть приложение:", reply_markup=kb)
